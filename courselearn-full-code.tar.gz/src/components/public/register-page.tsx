"use client";

import { useState, useEffect } from "react";
import { useAppStore } from "@/stores/app-store";
import { Button } from "@/components/ui/button";
import { LanguageSwitcher } from "@/components/shared/language-switcher";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BrandLogo } from "@/components/shared/brand-logo";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Mail, Lock, User, ArrowLeft, UserPlus, AlertCircle, CheckCircle2,
  ArrowRight, ArrowLeft as ArrowLeftIcon, Eye, EyeOff, ShieldCheck, Sparkles
} from "lucide-react";
import { apiPost } from "@/hooks/use-api";
import { useApiFetch } from "@/hooks/use-api";
import { toast } from "@/hooks/use-toast";
import { formatPrice, durationUnitLabel, type SubscriptionPlanPublic } from "@/types";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/i18n/store";

export function RegisterPage() {
  const { t } = useI18n();
  const navigate = useAppStore((s) => s.navigate);
  const query = useAppStore((s) => s.query);
  const refreshUser = useAppStore((s) => s.refreshUser);

  const { data, loading } = useApiFetch<{ plans: SubscriptionPlanPublic[] }>("/api/public/plans");
  const plans = data?.plans || [];

  const [step, setStep] = useState<1 | 2>(1);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [selectedPlanId, setSelectedPlanId] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Preselect plan from URL query
  useEffect(() => {
    if (query.planId && !selectedPlanId) {
      setSelectedPlanId(query.planId);
    }
  }, [query.planId, selectedPlanId]);

  const selectedPlan = plans.find((p) => p.id === selectedPlanId);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!selectedPlanId) {
      setError(t("auth.pleaseSelectPlan"));
      setStep(2);
      return;
    }
    setSubmitting(true);
    try {
      await apiPost("/api/auth/register", { name, email, password, planId: selectedPlanId });
      toast({
        title: t("auth.accountCreated"),
        description: t("auth.accountCreatedDesc"),
      });
      await refreshUser();
    } catch (e: any) {
      setError(e.message || "Registration failed");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="surface-gradient relative min-h-screen flex flex-col overflow-hidden bg-soft-sage/40">
      <div
        className="pointer-events-none absolute inset-0 -z-10 opacity-90"
        style={{
          background:
            "radial-gradient(circle at 15% 20%, rgba(120,151,134,0.18), transparent 45%), radial-gradient(circle at 85% 80%, rgba(52,79,66,0.08), transparent 45%)",
        }}
      />

      {/* Top bar */}
      <div className="flex items-center justify-between p-4 md:px-6 lg:px-8">
        <BrandLogo onClick={() => navigate([""])} />
        <div className="flex items-center gap-2">
          <LanguageSwitcher />
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate([""])}
            className="gap-2 h-9 text-foreground hover:bg-soft-sage"
          >
            <ArrowLeft className="h-4 w-4" /> {t("auth.backToHome")}
          </Button>
        </div>
      </div>

      <div className="flex flex-1 items-center justify-center px-4 pb-12">
        <Card className="animate-scale-in w-full max-w-2xl rounded-lg border border-border bg-card p-6 shadow-md md:p-8">
          {/* Header */}
          <div className="mb-6 space-y-3 text-center">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-lg bg-primary text-primary-foreground shadow-sm">
              <UserPlus className="h-6 w-6" />
            </div>
            <div className="space-y-1">
              <h1 className="font-heading text-xl font-semibold tracking-tight text-foreground md:text-2xl">
                {t("auth.createAccount")}
              </h1>
              <p className="text-sm text-muted-foreground">
                {t("auth.joinPlatform")}
              </p>
            </div>
          </div>

          {/* Stepper */}
          <div className="mb-8 flex items-center justify-center gap-3">
            <div
              className={cn(
                "flex items-center gap-2",
                step === 1 ? "text-primary" : "text-muted-foreground"
              )}
            >
              <span
                className={cn(
                  "flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold transition-all duration-200",
                  step === 1
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : step > 1
                    ? "bg-success text-success-foreground"
                    : "bg-muted text-muted-foreground"
                )}
              >
                {step > 1 ? <CheckCircle2 className="h-4 w-4" /> : "1"}
              </span>
              <span className="text-xs font-medium">{t("auth.yourDetails")}</span>
            </div>
            <span className="h-px w-10 bg-border" />
            <div
              className={cn(
                "flex items-center gap-2",
                step === 2 ? "text-primary" : "text-muted-foreground"
              )}
            >
              <span
                className={cn(
                  "flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold transition-all duration-200",
                  step === 2
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "bg-muted text-muted-foreground"
                )}
              >
                2
              </span>
              <span className="text-xs font-medium">{t("auth.selectPlan")}</span>
            </div>
          </div>

          <form onSubmit={onSubmit} className="space-y-5">
            {step === 1 && (
              <>
                <div className="space-y-1.5">
                  <Label htmlFor="name" className="text-sm font-medium">
                    {t("auth.fullName")}
                  </Label>
                  <div className="relative">
                    <User className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="name"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder={t("auth.yourFullNamePlaceholder")}
                      className="h-9 pl-9"
                      autoComplete="name"
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="email" className="text-sm font-medium">
                    {t("common.email")}
                  </Label>
                  <div className="relative">
                    <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder={t("auth.yourEmailAddress")}
                      className="h-9 pl-9"
                      autoComplete="email"
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="password" className="text-sm font-medium">
                      {t("common.password")}
                    </Label>
                    <button
                      type="button"
                      onClick={() => setShow((v) => !v)}
                      className="inline-flex items-center gap-1 text-xs text-muted-foreground transition-colors hover:text-foreground"
                    >
                      {show ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                      {show ? t("auth.hide") : t("auth.show")}
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="password"
                      type={show ? "text" : "password"}
                      required
                      minLength={6}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder={t("auth.atLeast6Chars")}
                      className="h-9 pl-9"
                      autoComplete="new-password"
                    />
                  </div>
                </div>

                {error && (
                  <div className="flex items-start gap-2 rounded-lg bg-destructive/10 p-3 text-sm text-destructive">
                    <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                <Button
                  type="button"
                  onClick={() => {
                    if (!name || !email || password.length < 6) {
                      setError(t("auth.pleaseCompleteFields"));
                      return;
                    }
                    setError(null);
                    setStep(2);
                  }}
                  className="h-10 w-full gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
                >
                  {t("auth.continueToPlan")}
                  <ArrowRight className="h-4 w-4" />
                </Button>

                <p className="text-center text-sm text-muted-foreground">
                  {t("auth.alreadyHaveAccount")}{" "}
                  <button
                    type="button"
                    onClick={() => navigate(["login"])}
                    className="font-medium text-primary transition-colors hover:text-primary/80 hover:underline"
                  >
                    {t("auth.signIn")}
                  </button>
                </p>
              </>
            )}

            {step === 2 && (
              <>
                <div>
                  <p className="mb-3 text-sm font-medium text-foreground">
                    {t("auth.choosePlan")}
                  </p>
                  {loading ? (
                    <div className="space-y-3">
                      {[1, 2, 3].map((i) => (
                        <Skeleton key={i} className="h-24 w-full" />
                      ))}
                    </div>
                  ) : plans.length === 0 ? (
                    <p className="text-sm text-muted-foreground">
                      {t("auth.noPlansAvailable")}
                    </p>
                  ) : (
                    <div className="max-h-[400px] space-y-3 overflow-y-auto scrollbar-thin pr-1">
                      {plans.map((p) => {
                        const selected = selectedPlanId === p.id;
                        return (
                          <button
                            type="button"
                            key={p.id}
                            onClick={() => setSelectedPlanId(p.id)}
                            className={cn(
                              "w-full rounded-lg border p-4 text-left transition-all duration-200",
                              selected
                                ? "border-primary bg-soft-sage/60 ring-1 ring-primary/30"
                                : "border-border bg-card hover:border-accent/40 hover:bg-soft-sage/30"
                            )}
                          >
                            <div className="flex items-start justify-between gap-3">
                              <div className="min-w-0 flex-1">
                                <div className="mb-1 flex items-center gap-2">
                                  <span className="font-heading text-sm font-semibold tracking-tight text-foreground">
                                    {p.name}
                                  </span>
                                  {p.isPopular && (
                                    <Badge className="bg-primary text-primary-foreground text-[10px]">
                                      <Sparkles className="h-2.5 w-2.5" /> {t("auth.popular")}
                                    </Badge>
                                  )}
                                  {selected && (
                                    <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-primary text-primary-foreground">
                                      <CheckCircle2 className="h-3 w-3" />
                                    </span>
                                  )}
                                </div>
                                {p.description && (
                                  <p className="line-clamp-1 text-xs text-muted-foreground">
                                    {p.description}
                                  </p>
                                )}
                                <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
                                  {p.features.slice(0, 3).map((f, i) => (
                                    <span key={i} className="flex items-center gap-1">
                                      <CheckCircle2 className="h-3 w-3 text-accent" /> {f}
                                    </span>
                                  ))}
                                </div>
                              </div>
                              <div className="shrink-0 text-right">
                                <p className="font-heading text-base font-bold tracking-tight text-foreground">
                                  {formatPrice(p.price, p.currency)}
                                </p>
                                <p className="text-xs text-muted-foreground">
                                  {p.duration} {durationUnitLabel(p.durationUnit).toLowerCase()}
                                </p>
                              </div>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>

                {selectedPlan && (
                  <div className="rounded-lg border border-border bg-soft-sage/40 p-4 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">{t("auth.selectedPlan")}</span>
                      <span className="font-medium text-foreground">{selectedPlan.name}</span>
                    </div>
                    <div className="mt-1 flex items-center justify-between">
                      <span className="text-muted-foreground">{t("auth.total")}</span>
                      <span className="font-heading font-bold tracking-tight text-foreground">
                        {formatPrice(selectedPlan.price, selectedPlan.currency)}
                      </span>
                    </div>
                  </div>
                )}

                {error && (
                  <div className="flex items-start gap-2 rounded-lg bg-destructive/10 p-3 text-sm text-destructive">
                    <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setStep(1)}
                    className="h-10 gap-2 border-border bg-card hover:bg-soft-sage"
                  >
                    <ArrowLeftIcon className="h-4 w-4" /> {t("common.back")}
                  </Button>
                  <Button
                    type="submit"
                    disabled={submitting || !selectedPlanId}
                    className="h-10 flex-1 gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
                  >
                    {submitting ? (
                      <>
                        <span className="h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground/30 border-t-primary-foreground" />
                        {t("auth.creatingAccount")}
                      </>
                    ) : (
                      <>
                        <UserPlus className="h-4 w-4" />
                        {t("auth.createAccountStart")}
                      </>
                    )}
                  </Button>
                </div>

                <p className="flex items-center justify-center gap-1.5 text-center text-xs text-muted-foreground">
                  <ShieldCheck className="h-3.5 w-3.5 text-accent" />
                  {t("auth.noPaymentProcessed")}
                </p>
              </>
            )}
          </form>
        </Card>
      </div>
    </div>
  );
}
